"""Top-level package for CREPE notes."""

__author__ = """Xavier Riley"""
__email__ = 'xavriley@hotmail.com'
__version__ = '0.1.0'
