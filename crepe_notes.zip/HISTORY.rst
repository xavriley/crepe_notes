=======
History
=======

0.1.0 (2022-09-07)
------------------

* First release on PyPI.
