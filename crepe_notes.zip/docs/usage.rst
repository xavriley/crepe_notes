=====
Usage
=====

To use CREPE notes in a project::

    import crepe_notes
